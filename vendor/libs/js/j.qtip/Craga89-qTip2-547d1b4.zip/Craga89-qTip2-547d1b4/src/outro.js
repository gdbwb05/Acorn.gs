
}(jQuery, window));