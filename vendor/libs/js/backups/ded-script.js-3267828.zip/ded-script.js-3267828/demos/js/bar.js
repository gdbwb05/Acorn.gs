console.log('loading bar...');
script.ready('main', function() {
  console.log('foo loaded: hello from ' + bar);
  window.thunkor = 'boosh';
});